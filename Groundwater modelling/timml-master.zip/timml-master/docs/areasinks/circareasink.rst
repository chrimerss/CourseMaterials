Circular Area-Sink
------------------

.. autoclass:: timml.circareasink.CircAreaSink