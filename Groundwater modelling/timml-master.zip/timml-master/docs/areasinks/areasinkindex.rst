Area-sinks
----------
There is a circular area-sink. In the future there will be a strip area-sink and a polygonal area-sink.
    
.. toctree::
    :maxdepth: 1
    :hidden:
    
    CircAreaSink <circareasink>
