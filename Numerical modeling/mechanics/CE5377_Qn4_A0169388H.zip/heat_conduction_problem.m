% grid size is N assume delta x= delta y
N=96;
dx=3/N;
u=zeros(N);
A_diag=eye(N-1)*(-4/(dx^2));
A_diag=A_diag+diag(ones(N-2,1),1)*1/(dx^2);
A_diag=A_diag+diag(ones(N-2,1),-1)*1/(dx^2);
A_off=eye(N-1)*(1/(dx^2));
A=eye((N-1)*(N-1),(N-1)*(N-1));
for i=1:N-1
  A((i-1)*(N-1)+1:(i-1)*(N-1)+(N-1),(i-1)*(N-1)+1:(i-1)*(N-1)+(N-1))=A_diag;
end
for i=2:N-1
    A((i-2)*(N-1)+1:(i-2)*(N-1)+(N-1),(i-1)*(N-1)+1:(i-1)*(N-1)+(N-1))=A_off;%upper diagnal
    A((i-1)*(N-1)+1:(i-1)*(N-1)+(N-1),(i-2)*(N-1)+1:(i-2)*(N-1)+(N-1))=A_off;%lower diagnol
end
% boundary condition
% left side and right side condition
A_new=eye(N*N-1,N*N-1);
A_new(N:N*(N-1),N:N*(N-1))=A;
A_new(1:N-1,1:N-1)=-eye(N-1)*1/dx^2;
A_new(N*(N-1)+1:end,N*(N-1)+1:end)=-eye(N-1)/dx^2;
A_new(N:2*N-2,1:N-1)=A_off;
A_new(1:N-1,N:2*N-2)=A_off;
A_new(N*(N-1)+1:end,(N-1)^2+1:N*(N-1))=A_off;
A_new((N-1)^2+1:N*(N-1),N*(N-1)+1:end)=A_off;
%openning condition 
  % donwside of opening area
A_new(N*N/2-1,:)=0;
A_new(N*N/2-1,N*N/2-1)=-1/dx^2;
A_new(N*N/2-1,N*N/2-2)=1/dx^2;
  % left side of opening area
A_new(N*N/2-(N-1),:)=0;
A_new(N*N/2-(N-1),N*N/2-(N-1))=-1/dx^2;
A_new(N*N/2-(N-1),N*N/2-(N-1)*2)=1/dx^2;
 %right side of opening area
A_new(N*N/2+(N-1),:)=0;
A_new(N*N/2+(N-1),N*N/2+(N-1))=-1/dx^2;
A_new(N*N/2+(N-1),N*N/2+(N-1)*2)=1/dx^2;
 %upside of opening area
A_new(N*N/2+1,:)=0;
A_new(N*N/2+1,N*N/2+1)=-1/dx^2;
A_new(N*N/2+1,N*N/2+2)=1/dx^2;
%boundary condition in up and down side
f=zeros(N*N-1,1);
f(N:N-1:(N-1)*(N-1)+1)=100/dx^2;
B=-A_new\f;
B=reshape(B,N-1,N+1);
surf(B)













