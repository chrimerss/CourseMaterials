function outcome=Trapezoidal_Newton(f,a,b,n,tol)
h=(b-a)/n;
T=a:h:b;
Y=zeros(1,n+1);
Q=zeros(1,n+1);
Q(1)=Y(1);
err=zeros(1,n+1);
for i=1:n
    Yt1=Y(i)+h*feval(f,T(i),Y(i)); % assume a initial value
    eps=1;
    while eps>tol
        %form a function
       Fx=Yt1-Y(i)-h/2*(feval(f,T(i+1),Yt1)+feval(f,T(i),Y(i)));
        %1st-order derivative depends on f
       dFx=1-h*3/2;
        % define a new x
       Yt2=Yt1-Fx/dFx;
       eps=abs(Yt2-Yt1); % decide when to abort
       Yt1=Yt2;
    end
    
    Y(i+1)=Y(i)+h*1/2*(feval(f,T(i),Y(i))+feval(f,T(i+1),Yt1));
    Q(i+1)=(-0.5)*exp(T(i+1))+0.5*exp(3*T(i+1));
    err(i+1)=abs(Q(i+1)-Y(i+1));
end
outcome=[T' Y' Q' err'];
end