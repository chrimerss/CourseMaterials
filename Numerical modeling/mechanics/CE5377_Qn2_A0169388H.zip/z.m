function test=z(t,y)
test=exp(t)+3*y;
end