function v=Trapezoidal_modified(f,a,b,n)
h=(b-a)/n;
T=a:h:b;
Y=zeros(1,n+1);
Y(1)=0;
Q(1)=Y(1);
err=zeros(1,n+1);
for i=1:n
    Yt=Y(i)+h*feval(f,T(i),Y(i));
    Y(i+1)=Y(i)+h*1/2*(feval(f,T(i+1),Yt)+feval(f,T(i),Y(i)));
    Q(i+1)=(-0.5)*exp(T(i+1))+0.5*exp(3*T(i+1));
    err(i+1)=Q(i+1)-Y(i+1);
end
v=[T' Y' Q' err'];
plot(T,Y,T,Q)
end