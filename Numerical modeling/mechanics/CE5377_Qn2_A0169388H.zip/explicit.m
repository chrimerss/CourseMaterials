function value=explicit(f,a,b,n)
Y=zeros(1,n+1);
T=zeros(1,n+1);
Q=zeros(1,n+1);
error=zeros(1,n+1);
h=(b-a)/n;
Y(1)=0;
Q(1)=Y(1);
T=a:h:b;
error(1)=0;
for i=1:n
    Y(i+1)=Y(i)+h*feval(f,T(i),Y(i))
    Q(i+1)=(-0.5)*exp(T(i+1))+0.5*exp(3*T(i+1));
    error(i+1)=Q(i+1)-Y(i+1);
end
value=[T' Y' Q' error'];
end