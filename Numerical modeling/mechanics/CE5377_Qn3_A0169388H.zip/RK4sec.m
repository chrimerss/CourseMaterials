function outcome=RK4sec(f,a,b,n)
h=(b-a)/n;
T=a:h:b;
y1=zeros(1,n+1);
y2=zeros(1,n+1);
y1(1)=1;
y2(1)=0;
Y=zeros(2,n+1);
Y=[y1;y2];
Q=zeros(1,n+1);
Q(1)=1;
err=zeros(1,n+1);
dy=zeros(1,n+1);
% since dy/dt=y2  dy2/dt=feval(f,t,y1) 
    %we're going to use RK4 twice for diffefent deriative.
for i=1:n
    %k1-4 is for feval(f,t,y1)
    k1=h*feval(f,T(i),y1(i));
    k2=h*feval(f,T(i)+h/2,k1/2+y1(i));
    k3=h*feval(f,T(i)+h/2,k2/2+y1(i));
    k4=h*feval(f,T(i)+h,k3+y1(i));
    K=(k1+2*k2+2*k3+k4)/6;
    %l1-4 is for dy/dt
    l1=h*y2(i);
    l2=h*(l1/2+y2(i));
    l3=h*(l2/2+y2(i));
    l4=h*(l3+y2(i));
    L=(l1+2*l2+2*l3+l4)/6;
    %-----------------------
    P(1,i)=L;
    P(2,i)=K;
    for j=1:2
    Y(j,i+1)=Y(j,i)+P(j,i);
    y1(i+1)=Y(1,i+1);
    y2(i+1)=Y(2,i+1);
    end
    Q(i+1)=cos(2*T(i+1))+1/4*T(i+1)*sin(2*T(i+1));
    err(i+1)=(abs(Q(i+1)-Y(1,i+1)))/Y(1,i+1)*100;
    dy(i+1)=-2*sin(2*T(i+1))+1/4*sin(2*T(i+1))+1/2*T(i+1)*cos(2*T(i+1));
end
outcome=[ T' Y' Q' err'  dy'];
plot(T,y1,T,Q);
legend('RK4','exact');
end
    