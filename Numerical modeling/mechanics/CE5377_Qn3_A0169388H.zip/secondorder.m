function out=secondorder(f,a,b,n)
y1=zeros(1,n+1);
y2=zeros(1,n+1);
y1(1)=1;
y2(1)=0;
Y=[y1',y2']';
h=(b-a)/n;
T=a:h:b;
Q=zeros(1,n+1);
Q(1)=1;
err=zeros(1,n+1);
for i=1:n
    for j=1:2
    Yt=[y2(i);feval(f,T(i),y1(i))];
    Y(j,i+1)=Y(j,i)+h*Yt(j);
    end
    y2(i+1)=Y(2,i+1);
    y1(i+1)=Y(1,i+1);
    Q(i+1)=cos(2*T(i+1))+1/4*T(i+1)*sin(2*T(i+1));
    err(i+1)=100*abs((Q(i+1)-Y(1,i+1))/Y(1,i+1));
end
out=[T;Y;Q;err]';
plot(T,y1,T,Q);
legend('Euler explicit','Exact');
xlabel('steps')
ylabel('value')
title('2nd-order Euler explicit method')
end