function test=z(t,y)
test=cos(2*t)-4*y;
end