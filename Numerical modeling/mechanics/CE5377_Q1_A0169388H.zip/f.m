% 2nd  question
function z=f(x)
z=(5.*exp(-x)-1)./(1-exp(-2.*x));
end