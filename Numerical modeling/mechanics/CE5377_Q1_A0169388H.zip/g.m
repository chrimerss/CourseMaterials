%1st question
function z=g(x)
z=x-sqrt(5);
end