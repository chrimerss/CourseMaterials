    function root=bisection(f,a,b,e)
 c=0;
    if f(a)*f(b)>0
            disp ('cannot find any root')
        else
           while abs(b-a)>e
               c=(b+a)/2;
               if f(a)*f(c)>0
                   a=c;
               elseif f(a)*f(c)<0
                   b=c;
               elseif f(c)==0
                   a=c;
                   b=c;    
               end
           end
           root=c;
fprintf (1,'%g\n',c)
        end
    end
