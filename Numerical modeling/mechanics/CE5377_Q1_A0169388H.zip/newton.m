function findzero=newton(f,a,e,n)
%a  first point(x)
for i=1:n
    x=a;
    dx=e;
    y=f(x);
    dy=f(x+dx)-f(x);
    k=((y+dy)-y)/((x+dx)-x);
    if abs(y)<e
        break
    elseif k*y<0
        a=a+abs(y/k);
    elseif k*y>0
       a=a-abs(y/k);
    end
    if a<=0 
        disp ('cannot find root,please change a')
        break
    end
end
 fprintf (1,'%g\n',a)
end
    
     